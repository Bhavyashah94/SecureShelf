import os
import random
import cv2
import json
from flask import Flask, render_template, Response, jsonify, request
from inference import SecureShelfEngine

app = Flask(__name__)

import threading
import time

app = Flask(__name__)

DATASET_DIR = r"C:\Users\bhavy\Documents\Project\SecureShelf\Dataset"
LATEST_PREDICTIONS = {0: {"prediction": "None", "confidence": 0}, 1: {"prediction": "None", "confidence": 0}}

def get_random_video():
    classes = ["Normal", "Shoplifting"]
    cls = random.choice(classes)
    cls_path = os.path.join(DATASET_DIR, cls)
    videos = [v for v in os.listdir(cls_path) if v.endswith(('.mp4', '.avi'))]
    if videos:
        return os.path.join(cls_path, random.choice(videos)), cls
    return None, None

class StreamWorker(threading.Thread):
    def __init__(self, sid):
        super().__init__(daemon=True)
        self.sid = sid
        self.engine = SecureShelfEngine()
        self.video_path = None
        self.latest_frame = None
        self.lock = threading.Lock()
        self.running = True

    def run(self):
        global LATEST_PREDICTIONS
        while self.running:
            if not self.video_path:
                self.video_path, _ = get_random_video()
            
            cap = cv2.VideoCapture(self.video_path)
            while cap.isOpened() and self.running:
                ret, frame = cap.read()
                if not ret:
                    self.video_path, _ = get_random_video()
                    self.engine.feature_buffer = []
                    break
                
                # AI Inference
                res = self.engine.process_frame(frame)
                LATEST_PREDICTIONS[self.sid] = {"prediction": res["prediction"], "confidence": res["confidence"]}
                
                # Annotate
                results = res.get("results")
                annotated = results[0].plot() if results else frame
                
                # Overlay
                color = (0, 255, 0) if res["prediction"] == "Normal" else (0, 0, 255)
                if res["prediction"] == "Initializing...": color = (255, 255, 255)
                
                cv2.rectangle(annotated, (5, 5), (180, 45), (40, 40, 40), -1)
                cv2.putText(annotated, f"CAM {self.sid+1:02d}: {res['prediction']}", (10, 25), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)
                cv2.putText(annotated, f"CONF: {res['confidence']:.2f}", (10, 40), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.4, (200, 200, 200), 1)

                # Store latest frame thread-safely
                with self.lock:
                    self.latest_frame = annotated
                
                # Small sleep to regulate FPS and give other threads time
                time.sleep(0.01)
            
            cap.release()

# Initialize workers (Reduced to 2)
workers = {i: StreamWorker(i) for i in range(2)}
for w in workers.values():
    w.start()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/random_video')
def api_random_video():
    sid = int(request.args.get('id', 0))
    path, label = get_random_video()
    if path:
        workers[sid].video_path = path
        workers[sid].engine.feature_buffer = []
        return jsonify({"path": path, "label": label, "name": os.path.basename(path), "sid": sid})
    return jsonify({"error": "No videos found"}), 404

def generate_frames(sid):
    while True:
        worker = workers.get(sid)
        if worker and worker.latest_frame is not None:
            with worker.lock:
                frame = worker.latest_frame.copy()
            
            ret, buffer = cv2.imencode('.jpg', frame)
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')
        else:
            # Placeholder or wait
            time.sleep(0.1)

@app.route('/video_feed/<int:sid>')
def video_feed(sid):
    return Response(generate_frames(sid), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/api/status')
def api_status():
    return jsonify(LATEST_PREDICTIONS)

@app.route('/api/switch_video')
def switch_video():
    sid = int(request.args.get('id', 0))
    path = request.args.get('path')
    if path and os.path.exists(path) and sid in workers:
        workers[sid].video_path = path
        workers[sid].engine.feature_buffer = []
        return jsonify({"status": "switched", "sid": sid})
    return jsonify({"error": "Invalid path or SID"}), 400

if __name__ == '__main__':
    app.run(debug=True, port=5000, threaded=True, use_reloader=False)
